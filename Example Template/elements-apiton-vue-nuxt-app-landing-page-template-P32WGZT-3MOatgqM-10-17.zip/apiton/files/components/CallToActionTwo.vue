<template>
  <section class="cta-two">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="cta-two__content">
            <div class="block-title text-left">
              <p>Feature List</p>
              <h3>Appton Providing You <br> Best Features</h3>
            </div><!-- /.block-title text-left -->
            <div class="cta-two__icon-wrap">
              <div class="cta-two__icon-single">
                <div class="cta-two__icon">
                  <i class="apton-icon-app-development"></i>
                </div><!-- /.cta-two__icon -->
                <h3>Responsive <br> Design</h3>
              </div><!-- /.cta-two__icon-single -->
              <div class="cta-two__icon-single">
                <div class="cta-two__icon">
                  <i class="apton-icon-computer-graphic1"></i>
                </div><!-- /.cta-two__icon -->
                <h3>Online <br> Marketing</h3>
              </div><!-- /.cta-two__icon-single -->
            </div><!-- /.cta-two__icon-wrap -->
            <div class="cta-two__text">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                fugiat nulla pariatur. Lorem Ipsum is simply dummy text of the printing laborum
                perspiciatis unde.</p>
            </div><!-- /.cta-two__text -->
            <a href="#" class="thm-btn cta-two__btn"><span>Discover More</span></a>
            <!-- /.thm-btn cta-two__btn -->
          </div><!-- /.cta-two__content -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6 ">
          <div class="cta-two__images d-flex justify-content-end align-items-end flex-column">
            <img src="/assets/images/resources/cta-2-moc-1.png" class="wow fadeInUp"
                 data-wow-duration="1500ms" alt="">
            <img src="/assets/images/resources/cta-2-moc-2.png" class="wow fadeInUp"
                 data-wow-duration="1500ms" alt="">
            <img src="/assets/images/resources/cta-2-moc-3.png" class="wow fadeInUp"
                 data-wow-duration="1500ms" alt="">
          </div><!-- /.cta-two__images -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CallToActionTwo"
    }
</script>

<style scoped>

</style>
