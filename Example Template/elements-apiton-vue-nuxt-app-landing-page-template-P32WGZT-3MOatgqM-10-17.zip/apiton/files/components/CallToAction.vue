<template>
  <section class="cta-one">
    <img src="/assets/images/shapes/cta-1-shape-1.png" class="cta-one__bg-shape-1" alt="">
    <img src="/assets/images/shapes/cta-1-shape-2.png" class="cta-one__bg-shape-2" alt="">
    <div class="container">
      <div class="cta-one__moc wow fadeInLeft" data-wow-duration="1500ms">
        <img src="/assets/images/resources/cta-1-moc-1.png" class="cta-one__moc-img" alt="">
      </div><!-- /.cta-one__moc -->
      <div class="row justify-content-end">
        <div class="col-lg-6">
          <div class="cta-one__content">
            <div class="block-title text-left">
              <p>Best Application</p>
              <h3>Powerful Application for <br> Your Projects</h3>
            </div><!-- /.block-title text-center -->
            <div class="cta-one__text">
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                fugiat nulla pariatur.</p>
            </div><!-- /.cta-one__text -->
            <ul class="list-unstyled cta-one__list">
              <li>
                <i class="fa fa-check-circle"></i>
                Refresing to get such a personal touch.
              </li>
              <li>
                <i class="fa fa-check-circle"></i>
                Duis aute irure dolor in reprehenderit in voluptate.
              </li>
              <li>
                <i class="fa fa-check-circle"></i>
                Velit esse cillum dolore eu fugiat nulla pariatur.
              </li>
            </ul><!-- /.list-unstyled -->
            <a href="#" class="thm-btn cta-one__btn"><span>Discover More</span></a>
            <!-- /.thm-btn cta-one__btn -->
          </div><!-- /.cta-one__content -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CallToAction"
    }
</script>

<style scoped>

</style>
