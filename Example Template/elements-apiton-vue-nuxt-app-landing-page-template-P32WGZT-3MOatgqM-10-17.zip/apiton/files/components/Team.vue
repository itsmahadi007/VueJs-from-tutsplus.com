<template>
  <section class="team-one" id="team">

    <img src="/assets/images/shapes/team-1-bg-1-1.png" class="team-one__bg-shape-1" alt="">
    <img src="/assets/images/shapes/team-1-bg-1-2.png" class="team-one__bg-shape-2" alt="">
    <div class="container">
      <div class="block-title text-center">
        <p>Expert People</p>
        <h3>Meet Our Professional <br> Team Members</h3>
      </div><!-- /.block-title text-center -->
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-12">
          <div class="team-one__single">
            <div class="team-one__circle"></div><!-- /.team-one__circle -->
            <div class="team-one__inner">
              <h3>Nathaniel McKenzie</h3>
              <p>App Designer</p>
              <div class="team-one__image">
                <img src="/assets/images/team/team-1-1.jpg" alt="">
              </div><!-- /.team-one__image -->
              <div class="team-one__social">
                <a href="#"><i class="fab fa-facebook-square"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__inner -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
        <div class="col-lg-3 col-md-6 col-sm-12">
          <div class="team-one__single">
            <div class="team-one__circle"></div><!-- /.team-one__circle -->
            <div class="team-one__inner">
              <h3>Ronald Parks</h3>
              <p>App Designer</p>
              <div class="team-one__image">
                <img src="/assets/images/team/team-1-2.jpg" alt="">
              </div><!-- /.team-one__image -->
              <div class="team-one__social">
                <a href="#"><i class="fab fa-facebook-square"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__inner -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
        <div class="col-lg-3 col-md-6 col-sm-12">
          <div class="team-one__single">
            <div class="team-one__circle"></div><!-- /.team-one__circle -->
            <div class="team-one__inner">
              <h3>Rachel Walker</h3>
              <p>App Designer</p>
              <div class="team-one__image">
                <img src="/assets/images/team/team-1-3.jpg" alt="">
              </div><!-- /.team-one__image -->
              <div class="team-one__social">
                <a href="#"><i class="fab fa-facebook-square"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__inner -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
        <div class="col-lg-3 col-md-6 col-sm-12">
          <div class="team-one__single">
            <div class="team-one__circle"></div><!-- /.team-one__circle -->
            <div class="team-one__inner">
              <h3>Willie Castillo</h3>
              <p>App Designer</p>
              <div class="team-one__image">
                <img src="/assets/images/team/team-1-4.jpg" alt="">
              </div><!-- /.team-one__image -->
              <div class="team-one__social">
                <a href="#"><i class="fab fa-facebook-square"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div><!-- /.team-one__social -->
            </div>
            <!-- /.team-one__inn
         -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Team"
    }
</script>

<style scoped>

</style>
