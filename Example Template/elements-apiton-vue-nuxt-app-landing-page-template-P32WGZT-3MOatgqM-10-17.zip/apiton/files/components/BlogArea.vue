<template>
  <section class="blog-one" id="blog">
    <div class="container">
      <div class="block-title text-center">
        <p>Latest News & Articles</p>
        <h3>Checkout What’s Going <br> on in Our Blog</h3>
      </div><!-- /.block-title text-center -->
      <div class="row">
        <div class="col-lg-4 ">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-1.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Leverage agile frame works to provide a synopsis
                  for</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4  -->
        <div class="col-lg-4 ">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-2.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Launch New Mobile App Marketing Pitfalls To
                  Avoid</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4  -->
        <div class="col-lg-4 ">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-3.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Bring to the table win-win survival strategies
                  domination.</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4  -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "BlogArea"
    }
</script>

<style scoped>

</style>
