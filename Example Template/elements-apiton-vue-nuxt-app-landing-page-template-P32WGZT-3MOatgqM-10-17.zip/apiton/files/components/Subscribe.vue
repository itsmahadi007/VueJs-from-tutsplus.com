<template>
  <section class="mailchimp-one">
    <div class="container wow fadeInUp" data-wow-duration="1500ms">
      <div class="inner-container">
        <div class="mailchimp-one__icon">
          <i class="apton-icon-mail"></i>
        </div><!-- /.mailchimp-one__icon -->
        <form action="#" class="mailchimp-one__form">
          <input type="text" placeholder="Enter your email address" name="email">
          <button class="thm-btn mailchimp-one__btn" type="submit"><span>Register Now</span></button>
          <!-- /.thm-btn -->
        </form><!-- /.mailchimp-one__form -->
      </div><!-- /.inner-container -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Subscribe"
    }
</script>

<style scoped>

</style>
