<template>
  <section class="blog-grid">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-1.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Leverage agile frame works to provide a synopsis for</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-2.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Launch New Mobile App Marketing Pitfalls To
                  Avoid</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-3.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Bring to the table win-win survival strategies domination.</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-4.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Capitalize on low hanging fruit to identify a activity</nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-5.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Collaboratively admin istrate empowered markets via </nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-6.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <div class="blog-one__circle"></div><!-- /.blog-one__circle -->
              <div class="blog-one__content-inner">
                <div class="blog-one__meta">
                  <a href="#"><i class="far fa-clock"></i> 20 Feb</a>
                  <a href="#"><i class="far fa-comments"></i> 2 comments</a>
                </div><!-- /.blog-one__meta -->
                <h3><nuxt-link to="/blog-details">Efficiently unleash cross-media information </nuxt-link></h3>
              </div><!-- /.blog-one__content-inner -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 col-md-6 col-sm-12 -->
      </div><!-- /.row -->
      <div class="post-pagination">
        <a href="#"><i class="far fa-angle-left"></i></a>
        <a href="#" class="active">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#"><i class="far fa-angle-right"></i></a>
      </div><!-- /.post-pagination -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Blog"
    }
</script>

<style scoped>

</style>
