<template>
  <section class="cta-three">
    <img src="/assets/images/shapes/cta-three-bg-1-1.png" class="cta-three__bg-1" alt="">
    <img src="/assets/images/shapes/cta-three-bg-1-2.png" class="cta-three__bg-2" alt="">
    <div class="container text-center">
      <h3>Download our App Today & <br> Experience Endless Possibilities</h3>
      <p>and get started with a free 1 month trial for your business </p>
      <div class="cta-three__btn-wrap">
        <a href="#" class="cta-three__btn">
          <i class="fa fa-play"></i>
          <span>Get in</span>
          <b>Google Play</b>
        </a><a href="#" class="cta-three__btn">
        <i class="fab fa-apple"></i>
        <span>Get in</span>
        <b>Apple Store</b>
      </a>
      </div><!-- /.cta-three__btn-wrap -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CallToActionThree"
    }
</script>

<style scoped>

</style>
